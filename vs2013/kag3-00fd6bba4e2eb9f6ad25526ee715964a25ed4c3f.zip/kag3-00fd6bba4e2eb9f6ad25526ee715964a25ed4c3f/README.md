# KAG3 for 吉里吉里SDL2

本フォルダ以下のデータ等は、KAG3 を吉里吉里SDL2で動くように最低限修正を加えたものです。  
β版に添付していたものを UTF-8 に変換しています。  
メニューは吉里吉里SDL2には実装されていないため、スタブされています。  
この例で使用されているフォント（`font.otf`に含まれています）は「[Source Han Sans Regular JP](https://github.com/adobe-fonts/source-han-sans/tree/release)」です。  

---
# KAG3 License
Copyright (C)2001-2009, W.Dee and contributors  改変・配布は自由です

